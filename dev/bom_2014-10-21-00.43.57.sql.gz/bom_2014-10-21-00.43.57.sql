--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_climateanalyseruser; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE auth_climateanalyseruser (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.auth_climateanalyseruser OWNER TO bom;

--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE auth_climateanalyseruser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_climateanalyseruser_id_seq OWNER TO bom;

--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE auth_climateanalyseruser_id_seq OWNED BY auth_climateanalyseruser.id;


--
-- Name: auth_climateanalyseruser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('auth_climateanalyseruser_id_seq', 1, false);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 57, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 44, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 13, true);


--
-- Name: climateanalyser_calculation; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_calculation (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    min_datafiles integer NOT NULL,
    max_datafiles integer NOT NULL
);


ALTER TABLE public.climateanalyser_calculation OWNER TO bom;

--
-- Name: climateanalyser_calculation_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_calculation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_calculation_id_seq OWNER TO bom;

--
-- Name: climateanalyser_calculation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_calculation_id_seq OWNED BY climateanalyser_calculation.id;


--
-- Name: climateanalyser_calculation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_calculation_id_seq', 2, true);


--
-- Name: climateanalyser_climateanalyserconfig; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_climateanalyserconfig (
    id integer NOT NULL,
    tilemill_server_address character varying(255) NOT NULL
);


ALTER TABLE public.climateanalyser_climateanalyserconfig OWNER TO bom;

--
-- Name: climateanalyser_climateanalyserconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_climateanalyserconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_climateanalyserconfig_id_seq OWNER TO bom;

--
-- Name: climateanalyser_climateanalyserconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_climateanalyserconfig_id_seq OWNED BY climateanalyser_climateanalyserconfig.id;


--
-- Name: climateanalyser_climateanalyserconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_climateanalyserconfig_id_seq', 1, false);


--
-- Name: climateanalyser_computation; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_computation (
    id integer NOT NULL,
    created_by_id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    completed_date timestamp with time zone,
    status_id integer NOT NULL,
    calculation_id integer NOT NULL,
    result_wms character varying(1000) NOT NULL,
    result_nc character varying(1000) NOT NULL,
    result_opendap character varying(1000) NOT NULL
);


ALTER TABLE public.climateanalyser_computation OWNER TO bom;

--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_computation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_computation_id_seq OWNER TO bom;

--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_computation_id_seq OWNED BY climateanalyser_computation.id;


--
-- Name: climateanalyser_computation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_computation_id_seq', 20, true);


--
-- Name: climateanalyser_computationdata; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_computationdata (
    id integer NOT NULL,
    datafile_id integer NOT NULL,
    computation_id integer NOT NULL,
    variables text NOT NULL
);


ALTER TABLE public.climateanalyser_computationdata OWNER TO bom;

--
-- Name: climateanalyser_computationdata_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_computationdata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_computationdata_id_seq OWNER TO bom;

--
-- Name: climateanalyser_computationdata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_computationdata_id_seq OWNED BY climateanalyser_computationdata.id;


--
-- Name: climateanalyser_computationdata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_computationdata_id_seq', 39, true);


--
-- Name: climateanalyser_datafile; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE climateanalyser_datafile (
    id integer NOT NULL,
    file_url character varying(1000) NOT NULL,
    cached_file character varying(1000) NOT NULL,
    variables text NOT NULL
);


ALTER TABLE public.climateanalyser_datafile OWNER TO bom;

--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE climateanalyser_datafile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.climateanalyser_datafile_id_seq OWNER TO bom;

--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE climateanalyser_datafile_id_seq OWNED BY climateanalyser_datafile.id;


--
-- Name: climateanalyser_datafile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('climateanalyser_datafile_id_seq', 4, true);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 46, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 19, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: zooadapter_zooadapterconfig; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE zooadapter_zooadapterconfig (
    id integer NOT NULL,
    zoo_server_address character varying(255) NOT NULL,
    thredds_server_address character varying(255) NOT NULL,
    zoo_public_key character(1000),
    zoo_private_key character(1000)
);


ALTER TABLE public.zooadapter_zooadapterconfig OWNER TO bom;

--
-- Name: zooadapter_zooadapterconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE zooadapter_zooadapterconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zooadapter_zooadapterconfig_id_seq OWNER TO bom;

--
-- Name: zooadapter_zooadapterconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE zooadapter_zooadapterconfig_id_seq OWNED BY zooadapter_zooadapterconfig.id;


--
-- Name: zooadapter_zooadapterconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('zooadapter_zooadapterconfig_id_seq', 1, false);


--
-- Name: zooadapter_zoocomputationstatus; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE zooadapter_zoocomputationstatus (
    code integer NOT NULL,
    status character varying(100) NOT NULL,
    details character varying(1000) NOT NULL
);


ALTER TABLE public.zooadapter_zoocomputationstatus OWNER TO bom;

--
-- Name: zooadapter_zoodashboard; Type: TABLE; Schema: public; Owner: bom; Tablespace: 
--

CREATE TABLE zooadapter_zoodashboard (
    id integer NOT NULL
);


ALTER TABLE public.zooadapter_zoodashboard OWNER TO bom;

--
-- Name: zooadapter_zoodashboard_id_seq; Type: SEQUENCE; Schema: public; Owner: bom
--

CREATE SEQUENCE zooadapter_zoodashboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.zooadapter_zoodashboard_id_seq OWNER TO bom;

--
-- Name: zooadapter_zoodashboard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bom
--

ALTER SEQUENCE zooadapter_zoodashboard_id_seq OWNED BY zooadapter_zoodashboard.id;


--
-- Name: zooadapter_zoodashboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bom
--

SELECT pg_catalog.setval('zooadapter_zoodashboard_id_seq', 1, false);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY auth_climateanalyseruser ALTER COLUMN id SET DEFAULT nextval('auth_climateanalyseruser_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_calculation ALTER COLUMN id SET DEFAULT nextval('climateanalyser_calculation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_climateanalyserconfig ALTER COLUMN id SET DEFAULT nextval('climateanalyser_climateanalyserconfig_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation ALTER COLUMN id SET DEFAULT nextval('climateanalyser_computation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computationdata ALTER COLUMN id SET DEFAULT nextval('climateanalyser_computationdata_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_datafile ALTER COLUMN id SET DEFAULT nextval('climateanalyser_datafile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY zooadapter_zooadapterconfig ALTER COLUMN id SET DEFAULT nextval('zooadapter_zooadapterconfig_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bom
--

ALTER TABLE ONLY zooadapter_zoodashboard ALTER COLUMN id SET DEFAULT nextval('zooadapter_zoodashboard_id_seq'::regclass);


--
-- Data for Name: auth_climateanalyseruser; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY auth_climateanalyseruser (id, user_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
28	Can add computation	10	add_computation
29	Can change computation	10	change_computation
30	Can delete computation	10	delete_computation
31	Can add data file	11	add_datafile
32	Can change data file	11	change_datafile
33	Can delete data file	11	delete_datafile
40	Can add computation data	14	add_computationdata
41	Can change computation data	14	change_computationdata
42	Can delete computation data	14	delete_computationdata
43	Can add zoo adapter config	15	add_zooadapterconfig
44	Can change zoo adapter config	15	change_zooadapterconfig
45	Can delete zoo adapter config	15	delete_zooadapterconfig
46	Can add ClimateAnalyser Config	16	add_climateanalyserconfig
47	Can change ClimateAnalyser Config	16	change_climateanalyserconfig
48	Can delete ClimateAnalyser Config	16	delete_climateanalyserconfig
49	Can add Dashboard	17	add_zoodashboard
50	Can change Dashboard	17	change_zoodashboard
51	Can delete Dashboard	17	delete_zoodashboard
52	Can add calculation	18	add_calculation
53	Can change calculation	18	change_calculation
54	Can delete calculation	18	delete_calculation
55	Can add zoo computation status	19	add_zoocomputationstatus
56	Can change zoo computation status	19	change_zoocomputationstatus
57	Can delete zoo computation status	19	delete_zoocomputationstatus
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
37	pbkdf2_sha256$12000$U42xp2jHgfrV$njKo9BVOF5+6IOm5SV25vj0uvR8fAwHZsW8E8wzlV3M=	2014-09-11 05:01:01.823799+00	f	meepo3	Me	epo	raigor_stonehoof@hotmail.com	f	t	2014-09-11 05:01:01.823799+00
32	pbkdf2_sha256$12000$nEalzli3cQPj$mK+9HDZf0BBPdOO0kQtZk18s4AOnl1EdceGocE/Fj5E=	2014-08-04 02:46:43.866028+00	f	dylan	Dylan	McTaggart	dylan.mctaggart1993@gmail.com	f	t	2014-07-19 11:20:04.609684+00
34	pbkdf2_sha256$12000$Nu8XDLxLJifR$VHWyyaExRFy4Vs4vxHPstxTH52w7NIgIt7b7nxy5W3A=	2014-07-21 00:37:39.51593+00	f	dylan2	Dylan	McTaggart	dylan.mctaggart1993@gmail.com	f	t	2014-07-21 00:37:28.683622+00
39	pbkdf2_sha256$12000$m0lVLPhGgoZH$WrXHnQqjJNoE3WHdR9SWtrv4Q1z5x/j70wT8eHOeKaI=	2014-09-14 15:32:37.625342+00	f	vin	vin	vin	vin@gmail.com	f	t	2014-09-14 15:32:37.625342+00
36	pbkdf2_sha256$12000$zCvy5fET2diP$Iaj648dKC597g1Tz3TkcF2QmLNXuSM3oUsFZS8dB/1Q=	2014-07-28 02:42:55.556157+00	f	test3	Test3	Test3	dylan.mctaggart1993@gmail.com	f	t	2014-07-28 02:42:39.621692+00
31	pbkdf2_sha256$12000$J26kUWCl02QG$11kTDOSksseIOuxl69mCw67H2dOg8Ml/YEskQGae1wc=	2014-06-02 13:38:15.680383+00	f	test12341	test	test	dylan.mctaggart1993@gmail.com	f	t	2014-06-02 13:38:15.680383+00
29	pbkdf2_sha256$12000$sLohopuCTHsH$rSeLg+FXplFqfyIiOBNlwn4gvFJdxFZZFwVf8GHPpSo=	2014-06-02 13:37:38.713198+00	f	test1234	test	test	dylan.mctaggart1993@gmail.com	f	t	2014-06-02 13:37:38.713198+00
33	pbkdf2_sha256$12000$oQ983Q7KumGQ$KxXr9YTJyvqv6qVE0QHAw/rKMSOJrqkIopMzzWjk9TI=	2014-10-05 23:16:11.735031+00	f	andrew	Andrew	Dunn	s3332747@student.rmit.edu.au	f	t	2014-07-19 11:54:44.470242+00
40	pbkdf2_sha256$12000$7eubqQwmyXzj$7gOmzDlfhQeF15BDXpboZhDRv71va7J/BtKWKQz0WgA=	2014-10-12 10:26:43.340619+00	f	calvin	calvin	calvin	s3312762@student.rmit.edu.au	f	t	2014-09-14 15:34:16.716842+00
2	pbkdf2_sha256$12000$Nnwo3LbLULCj$oIcLtmfwJwBb16vHV1AGgLTCs9SQtW/oW0RovwJ5ctI=	2014-10-13 00:18:55.103902+00	f	test1	Test	User1	s3334276@student.rmit.edu.au	f	t	2014-05-20 05:50:43+00
1	pbkdf2_sha256$12000$5sBCIUVoxQja$hJK75FEhoYec1gYcgMlzEEaA8zFAfeIHuatbGTaL5aY=	2014-10-21 00:00:34.525687+00	t	admin			s3334276@student.rmit.edu.au	t	t	2014-04-15 04:39:29.796747+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
1	2	32
2	2	33
3	2	11
4	2	13
5	2	14
6	2	15
7	2	16
8	2	17
9	2	18
10	2	28
11	2	29
12	2	30
13	2	31
\.


--
-- Data for Name: climateanalyser_calculation; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_calculation (id, name, min_datafiles, max_datafiles) FROM stdin;
1	correlate	2	2
2	regress	1	1
\.


--
-- Data for Name: climateanalyser_climateanalyserconfig; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_climateanalyserconfig (id, tilemill_server_address) FROM stdin;
1	130.102.155.34
\.


--
-- Data for Name: climateanalyser_computation; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_computation (id, created_by_id, created_date, completed_date, status_id, calculation_id, result_wms, result_nc, result_opendap) FROM stdin;
3	1	2014-09-27 10:54:16.912998+00	\N	0	1	http://115.146.84.143:8080/thredds/wms/datafiles/outputs/3.nc?service=WMS&version=1.3.0&request=GetCapabilities	http://115.146.84.143:8080/thredds/fileServer/datafiles/outputs/3.nc	http://115.146.84.143:8080/thredds/catalog/datafiles/outputs/catalog.html?dataset=climateAnalyserStorage/outputs/3.nc
18	2	2014-09-28 23:56:45.548388+00	\N	0	2	http://115.146.84.143:8080/thredds/wms/datafiles/outputs/18.nc?service=WMS&version=1.3.0&request=GetCapabilities	http://115.146.84.143:8080/thredds/fileServer/datafiles/outputs/18.nc	http://115.146.84.143:8080/thredds/catalog/datafiles/outputs/catalog.html?dataset=climateAnalyserStorage/outputs/18.nc
19	2	2014-09-28 23:56:45.548388+00	\N	0	1	http://115.146.84.143:8080/thredds/wms/datafiles/outputs/19.nc?service=WMS&version=1.3.0&request=GetCapabilities	http://115.146.84.143:8080/thredds/fileServer/datafiles/outputs/19.nc	http://115.146.84.143:8080/thredds/catalog/datafiles/outputs/catalog.html?dataset=climateAnalyserStorage/outputs/19.nc
20	40	2014-09-30 01:32:35.204167+00	\N	0	1	http://115.146.84.143:8080/thredds/wms/datafiles/outputs/20.nc?service=WMS&version=1.3.0&request=GetCapabilities	http://115.146.84.143:8080/thredds/fileServer/datafiles/outputs/20.nc	http://115.146.84.143:8080/thredds/catalog/datafiles/outputs/catalog.html?dataset=climateAnalyserStorage/outputs/20.nc
\.


--
-- Data for Name: climateanalyser_computationdata; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_computationdata (id, datafile_id, computation_id, variables) FROM stdin;
5	1	3	["random"]
6	2	3	["random"]
35	2	18	["random"]
36	3	19	["SSTA"]
37	4	19	["precip"]
38	4	20	["precip"]
39	4	20	["precip"]
\.


--
-- Data for Name: climateanalyser_datafile; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY climateanalyser_datafile (id, file_url, cached_file, variables) FROM stdin;
1	http://115.146.84.143:8080/thredds/fileServer/datafiles/sample/sample_1D.nc	620852b27224f373db923919087653f9.nc	"{\\"random\\": {\\"dimensions\\": 1, \\"name\\": \\"random\\"}}"
2	http://115.146.84.143:8080/thredds/fileServer/datafiles/sample/sample_3D.nc	91617a87859e03fecd7e8a67b8dd4446.nc	"{\\"random\\": {\\"dimensions\\": 3, \\"name\\": \\"random\\"}}"
3	http://115.146.84.143:8080/thredds/fileServer/datafiles/sample/ncseries65.nc	a009c52ffcde9e8c6f99eea862a13502.nc	"{\\"SSTA\\": {\\"dimensions\\": 1, \\"name\\": \\"SSTA\\"}}"
4	http://115.146.84.143:8080/thredds/fileServer/datafiles/sample/precip.mon.mean.nc	088942c0791c5a093862d709c64f11b3.nc	"{\\"precip\\": {\\"dimensions\\": 3, \\"name\\": \\"Average Monthly Rate of Precipitation\\"}}"
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2014-05-20 05:50:43.274397+00	1	4	2	test1	1	
2	2014-05-20 05:52:20.487972+00	1	4	2	test1	2	Changed first_name, last_name, email and user_permissions.
3	2014-05-27 05:59:32.055899+00	1	4	7	dylan	3	
4	2014-05-27 05:59:32.058114+00	1	4	9	dylan1	3	
5	2014-05-27 05:59:32.059756+00	1	4	10	dylan2	3	
6	2014-05-27 05:59:32.061007+00	1	4	3	test	3	
7	2014-05-27 06:01:30.020628+00	1	4	11	dylan	3	
8	2014-05-27 06:06:00.95671+00	1	4	12	dylan	3	
9	2014-06-03 04:11:26.369451+00	1	10	15	Computation object	1	
10	2014-07-14 03:06:45.421125+00	1	10	7	Computation object	2	Changed datafiles.
11	2014-07-14 03:07:22.019273+00	1	10	7	Computation object	2	Changed created_by and datafiles.
12	2014-07-14 03:07:26.465492+00	1	10	7	Computation object	2	Changed created_by and datafiles.
13	2014-07-14 03:07:40.629707+00	1	10	7	Computation object	2	Changed created_by and datafiles.
14	2014-07-14 03:11:13.440327+00	1	10	7	Computation object	2	Changed datafiles.
15	2014-07-14 03:11:26.08499+00	1	10	7	Computation object	2	Changed created_by and datafiles.
16	2014-07-14 04:00:23.757095+00	1	10	9	Computation object	2	Changed datafiles.
17	2014-07-14 04:01:00.884399+00	1	10	9	Computation object	2	Changed datafiles.
18	2014-07-14 04:01:07.809384+00	1	10	9	Computation object	2	Changed datafiles.
19	2014-07-14 04:41:16.145657+00	1	10	14	Computation object	3	
20	2014-07-14 04:44:32.301958+00	1	10	15	Computation object	3	
21	2014-07-19 11:18:05.383364+00	1	4	13	dylan	3	
22	2014-07-28 01:09:02.271474+00	1	4	32	dylan	2	Changed password.
23	2014-08-07 07:33:13.324395+00	1	15	1	Zoo Adapter Configuration	2	Changed zoo_server_address and thredds_server_address.
24	2014-08-07 09:41:53.952275+00	1	11	6	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	1	
25	2014-08-07 09:51:37.298416+00	1	11	6	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	3	
26	2014-08-07 09:52:39.845404+00	1	11	7	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	1	
27	2014-08-07 09:52:49.406208+00	1	11	7	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	3	
28	2014-08-07 11:30:33.077068+00	1	11	8	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	1	
29	2014-08-07 11:30:46.56368+00	1	11	8	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	3	
34	2014-08-07 11:36:48.63524+00	1	11	9	http://115.146.84.143:8080/thredds/dodsC/datafiles/sample/catalog.html?dataset=climateAnalyserStorage/sample/real_correlation.nc	3	
35	2014-08-11 01:05:14.218716+00	1	16	1	ClimateAnalyserConfig object	2	Changed tilemill_server_address.
36	2014-08-11 02:49:44.727393+00	1	15	1	Zoo Adapter Configuration	2	Changed zoo_public_key and zoo_private_key.
44	2014-09-12 08:41:00.631339+00	1	15	1	Zoo Adapter Configuration	2	Changed thredds_server_address.
45	2014-09-25 03:51:20.644039+00	1	10	68	Computation object	2	Added computation data "ComputationData object". Changed variables for computation data "ComputationData object".
46	2014-09-29 01:19:07.488205+00	1	16	1	ClimateAnalyserConfig object	2	Changed tilemill_server_address.
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
10	computation	climateanalyser	computation
11	data file	climateanalyser	datafile
14	computation data	climateanalyser	computationdata
15	zoo adapter config	zooadapter	zooadapterconfig
16	ClimateAnalyser Config	climateanalyser	climateanalyserconfig
17	Dashboard	zooadapter	zoodashboard
18	calculation	climateanalyser	calculation
19	zoo computation status	zooadapter	zoocomputationstatus
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
wxepr28tn3rgd2uz9uy9b7oigwhts729	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-02 23:35:54.161973+00
s93y0xiyvwdfk0612gceu3ckesjqjtze	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-06-28 09:51:15.960913+00
bp3flvj0y5e3k61zduprtdg482e8y0bh	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 00:36:47.77306+00
am548q4s3ih6wp0d3reik11jf5c80f88	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-05-27 02:03:24.413035+00
7ld81a95jirfsz48p5k7tlv19aquoaxr	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-05-27 02:03:24.552297+00
6jliqigi1dbfxqln4fvll84sa740gom7	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-06 08:10:37.389309+00
ajtlcppe330tmbnmls07ougix45tswu9	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-07-04 09:13:23.841764+00
ca52b1uof0kganq9z7nxnhetyfozyp9v	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 02:06:57.651467+00
n435xk8hbwaw0lnrdsh5vqv1fb3ykiz6	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 01:04:27.371618+00
rw6g7x26g2hdv4hn76v0h3d9370h5g2u	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-03 05:41:04.95315+00
fi9f6trhr1swkg0csvl0b7hfibbnb704	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-03 05:41:05.050022+00
l15v5m50dbdpz8x3sl4m2099a762dep7	ODU4YWNjY2NiMzM0Nzc3NTM4OTFlNTIzYmU0NTgzNmNmMGVjY2YwMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MzN9	2014-08-31 03:15:55.844611+00
juajkypcps8am6f8mxhwc6o9jl4u9k6t	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 02:43:02.562844+00
tjtgps4yqqzfi7emxkigbuj26bz8efor	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-15 00:49:09.174298+00
ceb4ra5d0kdhvdiqv5oiv5eka2lj67ah	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-15 07:49:17.867361+00
241ersbcnpjqrnmdzrgihtr7nj2uj0bi	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-08-11 01:08:31.717595+00
ag2ifiy5q2kkahx66j0xqujzlxkyiaz2	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-06-04 08:32:09.598481+00
4pxaezj3boipa3wtkbd7h8sgo19h4r4c	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-22 00:08:47.137196+00
u9a5m02k7mxtpyegeaycrxna2a8q5wf7	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-18 04:14:54.594775+00
rir5jvsqvxetadw8lj0ob340epe98vqc	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-09-26 08:38:53.724389+00
kezizlvzw4yrf10lohxltf7nh3ww7o0t	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-08-19 10:16:51.690045+00
f1lh3rxjzwlfqbbrt19fynz60sclrmse	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-12 09:20:20.22182+00
en597t9hjte2s52mrmt71wkk1dqrz5sg	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-12 09:20:20.319615+00
ha8qbswqyul9ebrk347h9ot96uoq3thr	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-30 19:36:28.339833+00
9kp8ehleu98bso0puulrcmqb5x102jdw	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-25 00:45:33.673233+00
z123xhskz9ke681mgrulzvvhh6iwjirt	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-12 10:20:14.411781+00
1yvbbcxz47ik50x4seroar8bm0vgaat4	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-06-12 10:20:14.50404+00
ald8ux2ejyy30dbxenuei8daxbrgmo1a	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-29 01:49:25.282633+00
v0kluvnw9o0l0llo4wy8te99g74i6kvi	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-09-01 00:23:01.45201+00
9wscj04zlxoz5yo7rtxhzytb1vimuund	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-06-12 10:24:56.835709+00
69t5tkq61pi2q872jksmrmpl7elb7w1g	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-29 02:29:07.901717+00
knvf7o8v6twpovfqsoas8kedqsbiilrz	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-06-17 03:09:30.400332+00
060qzuzhfr3lk9dmie3o5hk17qbbiobr	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-18 12:52:39.107656+00
rd5ver2p46f38q4p05vpdcysn1bs3e7d	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-01 16:54:26.89973+00
mgzzb882hukwror9ta1714764ervmrzv	OGY5ZmZmNmFiMjRlZDdlN2U4MjI3NTM3NGUyYzVjOTVkZDdmNGI5MDp7Il9hdXRoX3VzZXJfaWQiOjEzLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCJ9	2014-06-17 05:59:53.693639+00
e2p7t9kg8hmzo1y73kv0fyvwt0b6r2ar	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-30 19:08:40.029559+00
27mvs0pdxorcoqkfpr0vvxg7s8iuc3dq	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 00:21:05.581714+00
k5kltfk03e156z0eac0wzfzllsmkiity	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 00:36:47.865716+00
7cktloktc47bkd8k7kgpqv71d791e8wk	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 00:38:38.292204+00
zioi4741xyjgd92kr53nzcahv0lr8a99	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-19 01:50:45.65914+00
9w9wsfeky5u014o3obp3ji80p29denoc	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-04 01:21:00.097103+00
wbs7wab1xbf57auqvmu59tgd867f17px	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-25 05:18:44.27244+00
nv2cau0nst2kwlpuk4zvta2sti10yebq	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-13 19:09:51.474624+00
xbvkn7xbaydmbxy855bqcecqr0ih7uim	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-29 12:13:51.183698+00
qtxzw73w9zl5wbwjaonmlh0mjdd4yxid	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-28 15:51:38.378939+00
jmucerg08xnfpeg73a6gpwem935feuyd	MmZhZjNhZGNhMTQ3Y2FlOGM1YTE0ZGIzYmYwNmQ5ZWUyYTMwYTc2Mjp7Il9tZXNzYWdlcyI6IltbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdLFtcIl9fanNvbl9tZXNzYWdlXCIsMCw0MCxcIllvdSBtdXN0IGxvZ2luIHRvIHZpZXcgdGhhdCBwYWdlLlwiXSxbXCJfX2pzb25fbWVzc2FnZVwiLDAsNDAsXCJZb3UgbXVzdCBsb2dpbiB0byB2aWV3IHRoYXQgcGFnZS5cIl0sW1wiX19qc29uX21lc3NhZ2VcIiwwLDQwLFwiWW91IG11c3QgbG9naW4gdG8gdmlldyB0aGF0IHBhZ2UuXCJdXSJ9	2014-07-18 04:53:34.463205+00
qlr7rekbupo0gmn43zcjyvq2hx5j6biz	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 01:37:52.781401+00
r3svdawy4q2bzzkk3eumu7iqtx5rggop	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-07-24 08:45:55.597626+00
k67h769coxo641vyvsq262ifmc4y6bez	N2MwNDM2MDAwOGQwNjBiYmJjMmY2MjAzMTZkY2E0NGJlYzJlNDEwYTp7Il9hdXRoX3VzZXJfaWQiOjEsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=	2014-07-31 00:38:37.328887+00
8fp25oytvn7i7il1del15luvtgh481sf	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-11 00:56:19.339575+00
535ny8nc4ni1ebksrq3y7w1deb7oc75w	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-30 19:04:46.386957+00
j2bvqnuzh230vgn286j1pz8t3s3ijrok	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-18 02:26:39.638719+00
iqa98ramwl1bct7imr7237p2ijwuw9kw	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-30 19:05:16.623512+00
1bbepa18rlmoegsl0hu67aon72a7qo7g	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-15 08:03:33.01666+00
wfich7yyq9i3p0txys7qg58y0486isqp	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-31 11:07:12.611104+00
yfp5uhnr2802kh1vu4f9d5lqjgkvvbxf	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-27 04:53:30.055655+00
nsvfr87uv8l8meyuki8k14ojee0b7uxj	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-01 01:37:24.326172+00
yp4q8b0qqg7xoapa7o705u6v4qurxkti	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 13:01:49.143067+00
xh5346s2n3x9tgs3ize8r5zwv6px5mxw	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-29 02:40:29.448886+00
twf56csur5iqnygblnotvgb3ch67y4xq	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-09-06 08:22:47.852225+00
uft8rokn6icyb2b6nt973znyylo3wugr	ODU4YWNjY2NiMzM0Nzc3NTM4OTFlNTIzYmU0NTgzNmNmMGVjY2YwMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MzN9	2014-08-02 23:37:03.14651+00
ihxpw2xy7opkuvt4eimk3gmyxhxatt2h	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 01:04:27.105248+00
wrsreull0zpjzbdi3nk9qxj6x5j389q2	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-26 04:04:48.757078+00
gwhy6q3xzgy305kadclv9e62qkjf9wty	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-04 00:38:38.387238+00
ld8p8sn9ju8mmtjxau1r0ijc6m9rbx8p	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-08-02 11:20:45.815707+00
go87og5nxobssowa1l660uvttzbzbpd1	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-02 12:06:04.613832+00
n6u2einul1k87vt03srhai0e20xtoljg	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 01:24:16.417859+00
mnekykaios8rpb7nsvwfwdxf63vmco31	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-19 03:29:08.971884+00
euywtf0nvqd0zcrydzl4is6om39qybb2	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-18 01:25:29.570772+00
fwwq8nap2y6yxldujmgo50hprrtvv1lo	ODU4YWNjY2NiMzM0Nzc3NTM4OTFlNTIzYmU0NTgzNmNmMGVjY2YwMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MzN9	2014-09-26 05:54:33.956334+00
4gsfa3b3f5w9yag1sfe2rwoe9o91masm	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-15 07:23:37.922503+00
gd2x2sb0n1dwxpiu427mv8fn8qogg5nh	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-08-21 05:18:20.015719+00
utwcm3e3ka4fo4ari5ahc3f7vq6r9cuz	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-11 02:42:43.452503+00
mfhup93sirdacl33jv3hoam92l3dh0b2	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-08-31 16:37:36.667244+00
x2bjudoz95tgeg6grmvii09qatt18ddm	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-18 02:46:47.234158+00
d3sgxyyrri3ajb270n5emv8fmdxg92y4	YjJhNzRiMDMxMjNhM2ZlOGY5ZTIzNjVkMDU0NjJlZTlkZTMzMGFkODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6NDB9	2014-09-29 02:29:13.878513+00
hgxmbzz8q744mcfhv1g9bzzvz28c9ovg	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-01 02:01:49.997933+00
fjzdftri58koznas2bb2dvawdgn2d2tq	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-09-01 11:12:52.748223+00
dz0fvpwklxfckrpia3pin5ve9ydgkmdg	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-13 19:09:35.206164+00
zisiew75vfjdo6vmm006t0t9lll0l7te	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-13 19:55:14.888541+00
thzm9foblj2jup6mjoli44bfksse6ubl	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-07-18 04:23:29.727429+00
azes5i6angprcvsijhaxesubozbzjyzc	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-08-13 19:23:35.102531+00
nkzm2x4foabgojqtefm8eg2l5wyqmuba	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-03 19:11:42.311888+00
52oh2z7s78uvpljonh1kj77ncuwtrd08	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-26 06:03:06.593273+00
4gorhogp0u88e2vfio70wa4to91bjr1f	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-09-29 01:49:45.01594+00
kntl7zcznw71k310xva7uyei4ztigx6p	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-29 02:38:40.391514+00
lhg4pk08jho0xuc1syu3qme7yj3xrt8x	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-03 19:58:25.830132+00
x0c2q4x19l4959wtqz5ivpmopyw92380	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-09-13 01:40:13.464038+00
qc13d7ksvv3bbqdmnh393eww7fbk8wt6	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-09-03 19:21:47.950923+00
76dj5fz1rt80q0d9800cygepl0xfm59i	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-10-08 04:34:56.253016+00
im3d6h83ap9ifnkzfk8arwfivco2i6tb	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-10-08 08:51:33.108692+00
7is7yv0ks8023ar3cd9ydyh3oynz6gcl	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-10-09 02:44:04.965514+00
9emznv1jxzy5ex9r6sv5tldr5lapj3k2	ODU4YWNjY2NiMzM0Nzc3NTM4OTFlNTIzYmU0NTgzNmNmMGVjY2YwMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MzN9	2014-10-12 07:58:52.335086+00
hagunzgj9d4twx2wpw8zavln4nlcgdk2	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-11-02 15:25:42.968964+00
1ukrlgy8qn2gl1jm5kw21tuua294e1fo	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-13 00:46:05.571114+00
rmao4ztpjp7d1eh5u3pgs45y78d5djy7	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-11-02 23:20:05.613188+00
y6vgl8rdbv79kc5qi5v1lahemtfb0obt	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-11-02 23:20:05.65465+00
quozyzebomz00lmbrk068llx5stv7n9a	NzhjOGIwY2EzYTQ0YzllNWJkMDhiN2VkMTM3MGM3YTAyMGM3YjZhMTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2014-11-04 00:00:34.528108+00
q1eunibn5xy13a07ml9mb0crcq400pdu	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-11-04 00:17:37.486181+00
zdm1s27clk6ku41bemyrp37m5uu2c460	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-11-04 00:25:28.668878+00
u8136r2wpc6jni3sjsoradozrn3w5rvz	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-13 01:19:11.694596+00
q1af9vx9bqux20slfy4vekx99j0ul6kd	MzY0ODY3ZjU5OWNkMTdhMDU3YTdkNDY1NjRmMTBlNmRlYzFkOTdmNzp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6Mn0=	2014-10-14 01:24:32.643983+00
c9asj77fwuej3n31nds2u4qh5nqyjhjy	YjJhNzRiMDMxMjNhM2ZlOGY5ZTIzNjVkMDU0NjJlZTlkZTMzMGFkODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6NDB9	2014-10-26 10:26:43.342528+00
07qcdq17b0enynft2dwwf5ntebwn8qxa	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-26 23:47:44.078696+00
0r03f3zhblr545r2orocthz2a7jqeufp	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-26 23:53:05.464785+00
tejuq04hmd0d9s2tslwv5sw7q41bd8m5	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-26 23:56:28.068801+00
z2czcxy3yu6aotpdekfiemisvlywo1uo	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-26 23:56:28.114633+00
vy625ktv8nba9twv9d4gmpbv5gyekx41	NmRhY2FkMTA5MWQzYzc0ODkwNzUxYWZjOWViYTg5YzE1MDJhNmZhMDp7fQ==	2014-10-27 00:16:25.954325+00
\.


--
-- Data for Name: zooadapter_zooadapterconfig; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY zooadapter_zooadapterconfig (id, zoo_server_address, thredds_server_address, zoo_public_key, zoo_private_key) FROM stdin;
1	130.56.248.143	115.146.84.143:8080	-----BEGIN RSA PUBLIC KEY-----\r\nMEgCQQClTDkkjDpg3DshHpyA3ZetTRJlYwmtMLh3Z33iGorNXVQ5scgY5ZhO9x1f\r\nK69+qumbnupqkjKSoLa6buShjvyhAgMBAAE=\r\n-----END RSA PUBLIC KEY-----\r\n                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  	-----BEGIN RSA PRIVATE KEY-----\r\nMIIBPQIBAAJBAKVMOSSMOmDcOyEenIDdl61NEmVjCa0wuHdnfeIais1dVDmxyBjl\r\nmE73HV8rr36q6Zue6mqSMpKgtrpu5KGO/KECAwEAAQJADsUg1gMxtDX5kpwJn/os\r\n829PlX+j/bW8xe6ZcPquFx2PZTPaHB35wrqpByUXgL4a14dz746MWUxo7ZWUWPNL\r\ngQIjAO5t1M0ktDX60OEbmHDbmuANDl1fhGuhlPPcKchF75wyWscCHwCxerUZYq1Q\r\ng3P9mqjdABFh3rHkNFvv0cFDc6+xxVcCIwCsFq3PWzyO8Xct4sMGQhrot8O0dSqY\r\nnMlrsW6e1It7C4UlAh4WBETnC0i4zjXbZg5ArDt7yqaCysQE8h5pgbZv9S0CIwDs\r\nMVZfC/SFvrktoyHT0cDJ5VkBCzW+mSQ5xyLWF/nKxQiu\r\n-----END RSA PRIVATE KEY-----                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
\.


--
-- Data for Name: zooadapter_zoocomputationstatus; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY zooadapter_zoocomputationstatus (code, status, details) FROM stdin;
0	scheduled	
1	running	
2	success	
3	failed	URL error
4	failed	download error
5	failed	invalid file type
6	failed	duplicate ID
7	failed	computation error
8	failed	computation error - invalid variables/dimensions
9	failed	computation error - range error
10	failed	computation error - problem with calculation
11	failed	computation error - permissions error
\.


--
-- Data for Name: zooadapter_zoodashboard; Type: TABLE DATA; Schema: public; Owner: bom
--

COPY zooadapter_zoodashboard (id) FROM stdin;
\.


--
-- Name: auth_climateanalyseruser_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_pkey PRIMARY KEY (id);


--
-- Name: auth_climateanalyseruser_user_id_key; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: climateanalyser_calculation_name_key; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_calculation
    ADD CONSTRAINT climateanalyser_calculation_name_key UNIQUE (name);


--
-- Name: climateanalyser_calculation_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_calculation
    ADD CONSTRAINT climateanalyser_calculation_pkey PRIMARY KEY (id);


--
-- Name: climateanalyser_climateanalyserconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_climateanalyserconfig
    ADD CONSTRAINT climateanalyser_climateanalyserconfig_pkey PRIMARY KEY (id);


--
-- Name: climateanalyser_computation_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_pkey PRIMARY KEY (id);


--
-- Name: climateanalyser_computationdata_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_computationdata
    ADD CONSTRAINT climateanalyser_computationdata_pkey PRIMARY KEY (id);


--
-- Name: climateanalyser_datafile_file_url_key; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_datafile
    ADD CONSTRAINT climateanalyser_datafile_file_url_key UNIQUE (file_url);


--
-- Name: climateanalyser_datafile_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY climateanalyser_datafile
    ADD CONSTRAINT climateanalyser_datafile_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: zooadapter_zooadapterconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY zooadapter_zooadapterconfig
    ADD CONSTRAINT zooadapter_zooadapterconfig_pkey PRIMARY KEY (id);


--
-- Name: zooadapter_zoocomputationstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY zooadapter_zoocomputationstatus
    ADD CONSTRAINT zooadapter_zoocomputationstatus_pkey PRIMARY KEY (code);


--
-- Name: zooadapter_zoodashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: bom; Tablespace: 
--

ALTER TABLE ONLY zooadapter_zoodashboard
    ADD CONSTRAINT zooadapter_zoodashboard_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: climateanalyser_calculation_name_like; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_calculation_name_like ON climateanalyser_calculation USING btree (name varchar_pattern_ops);


--
-- Name: climateanalyser_computation_calculation_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computation_calculation_id ON climateanalyser_computation USING btree (calculation_id);


--
-- Name: climateanalyser_computation_created_by_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computation_created_by_id ON climateanalyser_computation USING btree (created_by_id);


--
-- Name: climateanalyser_computation_status_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computation_status_id ON climateanalyser_computation USING btree (status_id);


--
-- Name: climateanalyser_computationdata_computation_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computationdata_computation_id ON climateanalyser_computationdata USING btree (computation_id);


--
-- Name: climateanalyser_computationdata_datafile_id; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_computationdata_datafile_id ON climateanalyser_computationdata USING btree (datafile_id);


--
-- Name: climateanalyser_datafile_file_url_like; Type: INDEX; Schema: public; Owner: bom; Tablespace: 
--

CREATE INDEX climateanalyser_datafile_file_url_like ON climateanalyser_datafile USING btree (file_url varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_climateanalyseruser_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY auth_climateanalyseruser
    ADD CONSTRAINT auth_climateanalyseruser_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computation_calculation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_calculation_id_fkey FOREIGN KEY (calculation_id) REFERENCES climateanalyser_calculation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computation_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computation_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computation
    ADD CONSTRAINT climateanalyser_computation_status_id_fkey FOREIGN KEY (status_id) REFERENCES zooadapter_zoocomputationstatus(code) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computationdata_computation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computationdata
    ADD CONSTRAINT climateanalyser_computationdata_computation_id_fkey FOREIGN KEY (computation_id) REFERENCES climateanalyser_computation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: climateanalyser_computationdata_datafile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bom
--

ALTER TABLE ONLY climateanalyser_computationdata
    ADD CONSTRAINT climateanalyser_computationdata_datafile_id_fkey FOREIGN KEY (datafile_id) REFERENCES climateanalyser_datafile(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_93d2d1f8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT content_type_id_refs_id_93d2d1f8 FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_c0d12874; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT user_id_refs_id_c0d12874 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: auth_group; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_group FROM PUBLIC;
REVOKE ALL ON TABLE auth_group FROM postgres;
GRANT ALL ON TABLE auth_group TO postgres;
GRANT ALL ON TABLE auth_group TO bom;


--
-- Name: auth_group_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_group_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_group_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_group_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_group_id_seq TO bom;


--
-- Name: auth_group_permissions; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_group_permissions FROM PUBLIC;
REVOKE ALL ON TABLE auth_group_permissions FROM postgres;
GRANT ALL ON TABLE auth_group_permissions TO postgres;
GRANT ALL ON TABLE auth_group_permissions TO bom;


--
-- Name: auth_group_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_group_permissions_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_group_permissions_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_group_permissions_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_group_permissions_id_seq TO bom;


--
-- Name: auth_permission; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_permission FROM PUBLIC;
REVOKE ALL ON TABLE auth_permission FROM postgres;
GRANT ALL ON TABLE auth_permission TO postgres;
GRANT ALL ON TABLE auth_permission TO bom;


--
-- Name: auth_permission_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_permission_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_permission_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_permission_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_permission_id_seq TO bom;


--
-- Name: auth_user; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user FROM PUBLIC;
REVOKE ALL ON TABLE auth_user FROM postgres;
GRANT ALL ON TABLE auth_user TO postgres;
GRANT ALL ON TABLE auth_user TO bom;


--
-- Name: auth_user_groups; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user_groups FROM PUBLIC;
REVOKE ALL ON TABLE auth_user_groups FROM postgres;
GRANT ALL ON TABLE auth_user_groups TO postgres;
GRANT ALL ON TABLE auth_user_groups TO bom;


--
-- Name: auth_user_groups_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_groups_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_groups_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_groups_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_groups_id_seq TO bom;


--
-- Name: auth_user_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_id_seq TO bom;


--
-- Name: auth_user_user_permissions; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE auth_user_user_permissions FROM PUBLIC;
REVOKE ALL ON TABLE auth_user_user_permissions FROM postgres;
GRANT ALL ON TABLE auth_user_user_permissions TO postgres;
GRANT ALL ON TABLE auth_user_user_permissions TO bom;


--
-- Name: auth_user_user_permissions_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE auth_user_user_permissions_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE auth_user_user_permissions_id_seq FROM postgres;
GRANT ALL ON SEQUENCE auth_user_user_permissions_id_seq TO postgres;
GRANT ALL ON SEQUENCE auth_user_user_permissions_id_seq TO bom;


--
-- Name: django_admin_log; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_admin_log FROM PUBLIC;
REVOKE ALL ON TABLE django_admin_log FROM postgres;
GRANT ALL ON TABLE django_admin_log TO postgres;
GRANT ALL ON TABLE django_admin_log TO bom;


--
-- Name: django_admin_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE django_admin_log_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE django_admin_log_id_seq FROM postgres;
GRANT ALL ON SEQUENCE django_admin_log_id_seq TO postgres;
GRANT ALL ON SEQUENCE django_admin_log_id_seq TO bom;


--
-- Name: django_content_type; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_content_type FROM PUBLIC;
REVOKE ALL ON TABLE django_content_type FROM postgres;
GRANT ALL ON TABLE django_content_type TO postgres;
GRANT ALL ON TABLE django_content_type TO bom;


--
-- Name: django_content_type_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE django_content_type_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE django_content_type_id_seq FROM postgres;
GRANT ALL ON SEQUENCE django_content_type_id_seq TO postgres;
GRANT ALL ON SEQUENCE django_content_type_id_seq TO bom;


--
-- Name: django_session; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE django_session FROM PUBLIC;
REVOKE ALL ON TABLE django_session FROM postgres;
GRANT ALL ON TABLE django_session TO postgres;
GRANT ALL ON TABLE django_session TO bom;


--
-- PostgreSQL database dump complete
--

